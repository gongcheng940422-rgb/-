import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const QuitApp());

class QuitApp extends StatefulWidget {
  const QuitApp({super.key});
  @override
  State<QuitApp> createState() => _QuitAppState();
}

class _QuitAppState extends State<QuitApp> {
  ThemeMode _mode = ThemeMode.system;
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '戒 · QUIT',
        debugShowCheckedModeBanner: false,
        themeMode: _mode,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        home: HomePage(
          onThemeChanged: (dark) => setState(
            () => _mode = dark ? ThemeMode.dark : ThemeMode.light,
          ),
        ),
      );

  ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF438C78),
      brightness: brightness,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF101715) : const Color(0xFFF4F7F5),
      cardTheme: CardThemeData(
        elevation: 0,
        color: dark ? const Color(0xFF1B2421) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      appBarTheme: const AppBarTheme(centerTitle: false, elevation: 0),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onThemeChanged});
  final ValueChanged<bool> onThemeChanged;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _quitKey = 'quit_start';
  static const _dailyKey = 'daily_count';
  static const _priceKey = 'pack_price';
  static const _packKey = 'pack_count';
  static const _themeKey = 'dark_mode';

  DateTime? _quitAt;
  int _daily = 10;
  double _price = 25;
  int _packCount = 20;
  bool _dark = false;
  Timer? _ticker;
  int _urgeSeconds = 180;
  Timer? _urgeTimer;
  bool _urgeRunning = false;

  @override
  void initState() {
    super.initState();
    _load();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final stamp = p.getInt(_quitKey);
    if (!mounted) return;
    setState(() {
      _quitAt = stamp == null ? DateTime.now() : DateTime.fromMillisecondsSinceEpoch(stamp);
      _daily = p.getInt(_dailyKey) ?? 10;
      _price = p.getDouble(_priceKey) ?? 25;
      _packCount = p.getInt(_packKey) ?? 20;
      _dark = p.getBool(_themeKey) ?? false;
    });
    widget.onThemeChanged(_dark);
    if (stamp == null) await p.setInt(_quitKey, _quitAt!.millisecondsSinceEpoch);
  }

  Duration get _elapsed => _quitAt == null ? Duration.zero : DateTime.now().difference(_quitAt!);
  int get _avoided => (_elapsed.inMinutes / 1440 * _daily).floor();
  double get _saved => _avoided * _price / _packCount;

  String _duration(Duration d) {
    final days = d.inDays;
    final hours = d.inHours % 24;
    final minutes = d.inMinutes % 60;
    final seconds = d.inSeconds % 60;
    return '${days}天 ${hours.toString().padLeft(2, '0')}:'
        '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  Future<void> _restart() async {
    final now = DateTime.now();
    final p = await SharedPreferences.getInstance();
    await p.setInt(_quitKey, now.millisecondsSinceEpoch);
    if (!mounted) return;
    setState(() => _quitAt = now);
  }

  Future<void> _settings() async {
    final daily = TextEditingController(text: '$_daily');
    final price = TextEditingController(text: _price.toStringAsFixed(2));
    final pack = TextEditingController(text: '$_packCount');
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('戒烟设置'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: daily, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '原来每天抽几支')),
          TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: '每包价格')),
          TextField(controller: pack, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '每包支数')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('保存')),
        ],
      ),
    );
    if (result != true) return;
    final d = int.tryParse(daily.text);
    final pr = double.tryParse(price.text);
    final pc = int.tryParse(pack.text);
    if (d == null || pr == null || pc == null || d < 0 || pr < 0 || pc <= 0) return;
    final p = await SharedPreferences.getInstance();
    await p.setInt(_dailyKey, d);
    await p.setDouble(_priceKey, pr);
    await p.setInt(_packKey, pc);
    if (!mounted) return;
    setState(() { _daily = d; _price = pr; _packCount = pc; });
  }

  void _startUrge() {
    if (_urgeRunning) return;
    setState(() { _urgeRunning = true; _urgeSeconds = 180; });
    _urgeTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      if (_urgeSeconds <= 1) {
        t.cancel();
        setState(() { _urgeSeconds = 0; _urgeRunning = false; });
      } else {
        setState(() => _urgeSeconds--);
      }
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _urgeTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final elapsed = _elapsed;
    return Scaffold(
      appBar: AppBar(
        title: const Text('戒 · QUIT', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
        actions: [
          IconButton(tooltip: '设置', onPressed: _settings, icon: const Icon(Icons.tune_rounded)),
          IconButton(tooltip: '切换主题', onPressed: () async {
            final p = await SharedPreferences.getInstance();
            setState(() => _dark = !_dark);
            await p.setBool(_themeKey, _dark);
            widget.onThemeChanged(_dark);
          }, icon: Icon(_dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Card(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('每一次不点燃，都是一次胜利', style: TextStyle(fontSize: 14, color: Colors.grey)),
              const SizedBox(height: 18),
              const Text('连续无烟', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              FittedBox(alignment: Alignment.centerLeft, child: Text(_duration(elapsed), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1))),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: _metric('累计省下', '¥${_saved.toStringAsFixed(2)}', Icons.savings_outlined)),
                const SizedBox(width: 12),
                Expanded(child: _metric('少抽香烟', '$_avoided 支', Icons.smoke_free_rounded)),
              ]),
              const SizedBox(height: 16),
              OutlinedButton.icon(onPressed: () => _confirmRestart(), icon: const Icon(Icons.refresh_rounded), label: const Text('记录一次重新开始')),
            ]),
          )),
          const SizedBox(height: 14),
          const _SectionTitle('身体正在恢复'),
          Card(child: Column(children: const [
            _RecoveryRow(time: '20 分钟', title: '心率和血压开始下降', detail: '身体逐渐从尼古丁刺激中恢复'),
            Divider(height: 1, indent: 20, endIndent: 20),
            _RecoveryRow(time: '12 小时', title: '血液中的一氧化碳下降', detail: '血氧水平逐步恢复正常'),
            Divider(height: 1, indent: 20, endIndent: 20),
            _RecoveryRow(time: '2–12 周', title: '循环和肺功能改善', detail: '走路和运动可能逐渐轻松'),
            Divider(height: 1, indent: 20, endIndent: 20),
            _RecoveryRow(time: '1–9 个月', title: '咳嗽和气短可能减少', detail: '呼吸道纤毛功能逐渐恢复'),
          ])),
          const SizedBox(height: 14),
          const _SectionTitle('烟瘾急救 · 先撑过这 3 分钟'),
          Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
            const Text('烟瘾通常会像浪潮一样升起，再慢慢退去。先停下来，缓慢呼吸。', textAlign: TextAlign.center),
            const SizedBox(height: 14),
            Text('${(_urgeSeconds ~/ 60).toString().padLeft(2, '0')}:${(_urgeSeconds % 60).toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800, fontFeatures: [])),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: _urgeRunning ? null : _startUrge, icon: const Icon(Icons.air_rounded), label: Text(_urgeRunning ? '正在坚持…' : _urgeSeconds == 0 ? '再来一次' : '开始 3 分钟急救')),
          ]))),
          const SizedBox(height: 14),
          Card(color: Theme.of(context).colorScheme.primaryContainer, child: const Padding(
            padding: EdgeInsets.all(18),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.favorite_rounded),
              SizedBox(width: 12),
              Expanded(child: Text('如果今天有波动，也不代表之前的努力白费。看见烟瘾、等待它过去，再做下一个选择。', style: TextStyle(height: 1.5))),
            ]),
          )),
        ],
      ),
    );
  }

  Future<void> _confirmRestart() async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('重新开始计时？'),
      content: const Text('这会重置当前连续无烟计时。累计数据会按新的开始时间重新计算。'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('重新开始')),
      ],
    ));
    if (ok == true) await _restart();
  }

  Widget _metric(String label, String value, IconData icon) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .55), borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 20),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
    ]),
  );
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
    child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
  );
}

class _RecoveryRow extends StatelessWidget {
  const _RecoveryRow({required this.time, required this.title, required this.detail});
  final String time, title, detail;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 7, height: 7, margin: const EdgeInsets.only(top: 7), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, shape: BoxShape.circle)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(time, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700, fontSize: 12)),
        const SizedBox(height: 3),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text(detail, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ])),
    ]),
  );
}
