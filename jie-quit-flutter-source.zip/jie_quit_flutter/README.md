# 戒 · QUIT

一个简体中文、离线优先的 Flutter 戒烟辅助 App。

## 当前版本
- 无烟计时
- 根据每日吸烟量、每包价格估算少抽数量与省钱金额
- 身体恢复时间轴
- 3 分钟烟瘾急救计时
- 本地保存设置与开始时间（SharedPreferences）
- 浅色 / 深色主题
- Android APK 由 GitHub Actions 云端构建

## 云端构建
将仓库文件上传到 GitHub 默认分支 `main` 或 `master`，然后打开仓库的 **Actions** 页面，运行 `Build Android APK`。成功后进入对应 workflow run，在 Artifacts 下载 `jie-quit-android-apk`。

## 说明
本项目是可运行的 MVP。当前“重新开始”会重置当前无烟计时；尚未实现多次戒烟历史档案、图表统计、成就系统和诱因日志。身体恢复时间为一般性参考，不构成医疗建议。
