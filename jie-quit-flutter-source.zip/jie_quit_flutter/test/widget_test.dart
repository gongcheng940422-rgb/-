import 'package:flutter_test/flutter_test.dart';
import 'package:jie_quit/main.dart';

void main() {
  testWidgets('shows app title and quit dashboard', (tester) async {
    await tester.pumpWidget(const QuitApp());
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('戒 · QUIT'), findsOneWidget);
    expect(find.text('连续无烟'), findsOneWidget);
    expect(find.text('身体正在恢复'), findsOneWidget);
  });
}
